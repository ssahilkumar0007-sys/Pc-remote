package com.example.pcremote

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val blue = 0xFF1687FF.toInt(); private val panel = 0xFF111722.toInt(); private val text = 0xFFF4F7FB.toInt()
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(buildUi()); requestBt() }

    private fun requestBt() { if (android.os.Build.VERSION.SDK_INT >= 31) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 20) }

    private fun buildUi(): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(18,12,18,12); root.setBackgroundColor(0xFF05070B.toInt())
        val top=LinearLayout(this); top.orientation=LinearLayout.HORIZONTAL
        val title=TextView(this); title.text="  🖥  PC Remote\n      Keyboard • Mouse • Control"; title.textColor=text; title.textSize=19f; top.addView(title, LinearLayout.LayoutParams(0,70,1f))
        val status=TextView(this); status.text="● Bluetooth: Ready"; status.textColor=0xFF4DFF6A.toInt(); status.textSize=16f; top.addView(status,LinearLayout.LayoutParams(260,70)); root.addView(top)
        val mid=LinearLayout(this); mid.orientation=LinearLayout.HORIZONTAL
        mid.addView(btn("LEFT CLICK",150)); mid.addView(btn("RIGHT CLICK",150));
        val pad=TextView(this); pad.text="\n\n\n\n     MOVE CURSOR\n\n\n\n"; pad.gravity=17; pad.textColor=text; pad.textSize=20f; pad.setBackgroundColor(panel); pad.setOnTouchListener{_,e-> handlePad(e); true}; mid.addView(pad,LinearLayout.LayoutParams(0,220,1f)); mid.addView(btn("SCROLL",150)); root.addView(mid)
        val keys=LinearLayout(this); keys.orientation=LinearLayout.VERTICAL
        val rows=listOf("ESC F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12", "TAB Q W E R T Y U I O P [ ] BACK", "CAPS A S D F G H J K L ; ENTER", "SHIFT Z X C V B N M , . / SHIFT", "CTRL WIN ALT SPACE ALT MENU CTRL")
        rows.forEach{ row-> val r=LinearLayout(this); row.split(" ").forEach{ k-> val b=btn(k,0); r.addView(b,LinearLayout.LayoutParams(0,52,1f)) }; keys.addView(r) }
        root.addView(keys); return root
    }
    private fun btn(s:String,w:Int):Button { val b=Button(this); b.text=s; b.textSize=12f; b.setTextColor(text); b.setBackgroundColor(panel); b.setOnClickListener{}; return b }
    private fun handlePad(e:MotionEvent):Boolean { return true }
}
